# Flappy Edu
 
 
 [![EDU_Voando_001](sprites/bird/EDU_Voando_001.png)](sprites/bird/EDU_Voando_001.png)
